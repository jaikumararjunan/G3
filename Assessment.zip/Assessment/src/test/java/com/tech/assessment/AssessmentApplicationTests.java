package com.tech.assessment;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
