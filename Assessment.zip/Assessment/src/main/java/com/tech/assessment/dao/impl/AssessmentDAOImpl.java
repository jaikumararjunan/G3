package com.tech.assessment.dao.impl;

import com.tech.assessment.dao.AssessmentDAO;

public class AssessmentDAOImpl implements AssessmentDAO {

}
