/**
 * 
 */
package com.tech.assessment.service;

/**
 * @author Jaikumar
 *
 */
public class AssessmentService {

}
