package com.tech.assessment.model;

public class Supplier {
	private int taxNumber;
	private int orderDuration;
	public int getTaxNumber() {
		return taxNumber;
	}
	public void setTaxNumber(int taxNumber) {
		this.taxNumber = taxNumber;
	}
	public int getOrderDuration() {
		return orderDuration;
	}
	public void setOrderDuration(int orderDuration) {
		this.orderDuration = orderDuration;
	}
}
