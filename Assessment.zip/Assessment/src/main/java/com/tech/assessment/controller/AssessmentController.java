package com.tech.assessment.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AssessmentController {

}
