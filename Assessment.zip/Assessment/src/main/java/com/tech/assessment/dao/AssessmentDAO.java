/**
 * 
 */
package com.tech.assessment.dao;

/**
 * @author Jaikumar
 *
 */
public interface AssessmentDAO {

}
